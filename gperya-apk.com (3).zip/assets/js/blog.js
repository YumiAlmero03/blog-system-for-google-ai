(() => {
  const containers = document.querySelectorAll('.blog-content');
  if (!containers.length) return;

  const noPaginateValues = new Set(['0', 'false', 'no', 'off']);

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  async function readJson(response) {
    const contentType = response.headers.get('content-type') || '';
    const text = await response.text();

    if (!contentType.includes('application/json')) {
      const cleanText = text.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
      throw new Error(cleanText || 'Server returned a non-JSON response.');
    }

    let payload = null;
    try {
      payload = JSON.parse(text);
    } catch (error) {
      throw new Error('Server returned invalid JSON.');
    }

    if (!response.ok || !payload || payload.ok === false) {
      throw new Error((payload && payload.error) || 'Request failed.');
    }

    return payload;
  }

  function blogUrl(post) {
    const slug = post.slug || post.id || '';
    return '/blog/' + encodeURIComponent(slug) + '/';
  }

  function renderPosts(grid, posts) {
    grid.innerHTML = posts.map((post) => {
      const url = blogUrl(post);
      const image = post.featuredImage || '/uploads/blogs/default-featured.svg';
      const categoryLabel = post.category || 'Guide';
      const dateLabel = post.date || post.dateLabel || '';
      const title = post.title || 'Untitled blog post';

      return `
        <article class="article-card blog-card">
          <a class="article-thumb blog-card-media" href="${escapeHtml(url)}" aria-label="${escapeHtml(title)}">
            <img src="${escapeHtml(image)}" alt="${escapeHtml(title)}" width="1200" height="675" loading="lazy" decoding="async">
            <span class="blog-card-chip">${escapeHtml(categoryLabel)}</span>
          </a>
          <div class="article-body blog-card-body">
            <div class="article-meta blog-card-meta">
              ${dateLabel ? `<time>${escapeHtml(dateLabel)}</time>` : '<span>Latest</span>'}
            </div>
            <h2 class="article-title blog-card-title"><a href="${escapeHtml(url)}">${escapeHtml(title)}</a></h2>
            <p class="article-excerpt blog-card-excerpt">${escapeHtml(post.excerpt || '')}</p>
            <a href="${escapeHtml(url)}" class="blog-card-link">Read Post</a>
          </div>
        </article>
      `;
    }).join('');
  }

  function setStatus(status, message, state) {
    if (!status) return;
    status.textContent = message || '';
    status.dataset.state = state || '';
  }

  function setLoading(grid, status) {
    grid.innerHTML = `
      <article class="blog-card-skeleton" aria-hidden="true"></article>
      <article class="blog-card-skeleton" aria-hidden="true"></article>
      <article class="blog-card-skeleton" aria-hidden="true"></article>
    `;
    setStatus(status, 'Loading posts...', 'loading');
  }

  function initBlogList(container) {
    const grid = container.querySelector('section.blog-grid');
    if (!grid) return;

    const status = container.querySelector(':scope > .blog-status') || container.querySelector('.blog-status');
    const pagination = container.querySelector('.blog-pagination');
    const pageLabel = pagination ? pagination.querySelector('.blog-status') : null;
    const prevBtn = pagination ? pagination.querySelector('.btn-prev') : null;
    const nextBtn = pagination ? pagination.querySelector('.btn-next') : null;
    const params = new URLSearchParams(window.location.search);
    const count = Number.parseInt(container.dataset.count || grid.dataset.count || params.get('count') || '6', 10);
    const category = (container.dataset.category || grid.dataset.category || params.get('category') || '').trim();
    const paginateValue = (container.dataset.paginate || 'on').trim().toLowerCase();
    const shouldPaginate = !noPaginateValues.has(paginateValue);

    let page = Math.max(1, Number.parseInt(params.get('page') || '1', 10) || 1);
    let totalPages = 1;
    let isLoading = false;

    function updatePagination() {
      if (!pagination || !prevBtn || !nextBtn || !shouldPaginate || totalPages <= 1) {
        if (pagination) pagination.style.display = 'none';
        return;
      }

      if (pageLabel) {
        pageLabel.textContent = 'Page ' + page + ' of ' + totalPages;
      }
      prevBtn.disabled = page <= 1 || isLoading;
      nextBtn.disabled = page >= totalPages || isLoading;
      pagination.style.display = 'flex';
    }

    async function loadPosts() {
      if (isLoading) return;
      isLoading = true;
      setLoading(grid, status);
      updatePagination();

      const request = new URL('/api/blog-post-list.php', window.location.origin);
      request.searchParams.set('count', String(Number.isFinite(count) && count > 0 ? count : 6));
      request.searchParams.set('page', String(shouldPaginate ? page : 1));
      if (category) request.searchParams.set('category', category);

      const response = await fetch(request.toString(), {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'X-Requested-With': 'fetch'
        }
      });
      const payload = await readJson(response);
      const posts = payload.blogs || [];
      totalPages = payload.pagination ? payload.pagination.totalPages : 1;
      page = payload.pagination ? payload.pagination.page : page;

      if (!posts.length) {
        grid.innerHTML = '';
        setStatus(status, category ? 'No blog posts found for this category.' : 'No blog posts found.', 'empty');
        return;
      }

      setStatus(status, '', 'ready');
      renderPosts(grid, posts);
    }

    function finishLoad() {
      isLoading = false;
      updatePagination();
    }

    function showError(error) {
      grid.innerHTML = '';
      setStatus(status, error.message || 'Unable to load blog posts.', 'error');
      isLoading = false;
      updatePagination();
    }

    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        if (page <= 1 || isLoading) return;
        page -= 1;
        loadPosts().then(finishLoad).catch(showError);
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        if (page >= totalPages || isLoading) return;
        page += 1;
        loadPosts().then(finishLoad).catch(showError);
      });
    }

    loadPosts().then(finishLoad).catch(showError);
  }

  containers.forEach(initBlogList);
})();
