/* GperyaPH Vanilla JavaScript Interactive Module */
document.addEventListener('DOMContentLoaded', () => {
  initMobileMenu();
  initAccordions();
  initTabs();
  initGameFavorites();
  initFloatBar();
  initCarousel();
  initSpinWheelWidget();
  initCustomBlogsInjector();
  initSecretAdminShortcut();
  enhanceAffiliateLinks();
  initDynamicWinnerMarquee();
  initPragmaticDemoSection();

  runWhenIdle(() => {
    initJoinNowPopupModal();
    initBottomLeftFloatingCTA();
  });
});

function getPlaynowRel() {
  return window.location.pathname.replace(/\/+$/, '').startsWith('/blog')
    ? 'noopener'
    : 'sponsored nofollow noopener';
}

function runWhenIdle(callback) {
  if ('requestIdleCallback' in window) {
    window.requestIdleCallback(callback, { timeout: 2500 });
    return;
  }

  setTimeout(callback, 1200);
}

/* Mobile Menu Drawer */
function initMobileMenu() {
  const menuBtn = document.querySelector('.mobile-menu-btn');
  const drawer = document.querySelector('.mobile-drawer');
  const closeBtn = document.querySelector('.drawer-close-btn');

  if (!menuBtn || !drawer) return;

  function openDrawer() {
    drawer.classList.add('open');
    menuBtn.setAttribute('aria-expanded', 'true');
    if (closeBtn) closeBtn.focus();
    document.body.style.overflow = 'hidden';
  }

  function closeDrawer() {
    drawer.classList.remove('open');
    menuBtn.setAttribute('aria-expanded', 'false');
    menuBtn.focus();
    document.body.style.overflow = '';
  }

  menuBtn.addEventListener('click', openDrawer);
  if (closeBtn) closeBtn.addEventListener('click', closeDrawer);

  drawer.addEventListener('click', (e) => {
    if (e.target === drawer) closeDrawer();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && drawer.classList.contains('open')) {
      closeDrawer();
    }
  });
}

/* Accordion FAQ */
function initAccordions() {
  const accordionHeaders = document.querySelectorAll('.accordion-header');

  accordionHeaders.forEach(header => {
    header.addEventListener('click', () => {
      const item = header.closest('.accordion-item');
      if (!item) return;

      const isOpen = item.classList.contains('open');

      item.classList.toggle('open');
      header.setAttribute('aria-expanded', !isOpen);
    });
  });
}

/* Category Tabs */
function initTabs() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabPanels = document.querySelectorAll('.tab-panel');

  if (!tabBtns.length) return;

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-tab');

      tabBtns.forEach(b => {
        b.classList.remove('active');
        b.setAttribute('aria-selected', 'false');
      });

      tabPanels.forEach(p => {
        p.classList.remove('active');
      });

      btn.classList.add('active');
      btn.setAttribute('aria-selected', 'true');

      const activePanel = document.getElementById(targetId);
      if (activePanel) {
        activePanel.classList.add('active');
      }
    });
  });
}

/* Local Favorites */
function initGameFavorites() {
  const favBtns = document.querySelectorAll('.game-fav-btn');
  const favs = JSON.parse(localStorage.getItem('gperya_fav_games') || '[]');

  favBtns.forEach(btn => {
    const gameId = btn.getAttribute('data-game-id');
    if (favs.includes(gameId)) {
      btn.style.color = '#b4232f';
      btn.setAttribute('aria-label', 'Remove from favorites');
    }

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();

      let currentFavs = JSON.parse(localStorage.getItem('gperya_fav_games') || '[]');
      if (currentFavs.includes(gameId)) {
        currentFavs = currentFavs.filter(id => id !== gameId);
        btn.style.color = 'var(--brand)';
        btn.setAttribute('aria-label', 'Add to favorites');
      } else {
        currentFavs.push(gameId);
        btn.style.color = '#b4232f';
        btn.setAttribute('aria-label', 'Remove from favorites');
      }
      localStorage.setItem('gperya_fav_games', JSON.stringify(currentFavs));
    });
  });
}

/* Desktop Floating Bar */
function initFloatBar() {
  const floatBar = document.querySelector('.desktop-float-bar');
  const closeBtn = document.querySelector('.float-bar-close');

  if (!floatBar || !closeBtn) return;

  if (sessionStorage.getItem('gperya_float_dismissed') === 'true') {
    floatBar.classList.add('hidden');
  }

  closeBtn.addEventListener('click', () => {
    floatBar.classList.add('hidden');
    sessionStorage.setItem('gperya_float_dismissed', 'true');
  });
}

/* Infinite Scroll Carousel for Popular Game & Category Overviews */
function initCarousel() {
  const carouselContainers = document.querySelectorAll('.carousel-container');

  carouselContainers.forEach(container => {
    const track = container.querySelector('.carousel-track');
    const prevBtn = container.querySelector('.carousel-nav-btn.prev');
    const nextBtn = container.querySelector('.carousel-nav-btn.next');

    if (!track) return;
    if (track.dataset.infiniteInit === 'true') return;
    track.dataset.infiniteInit = 'true';

    const originalCards = Array.from(track.children);
    if (originalCards.length === 0) return;

    const getScrollStep = () => {
      const card = track.firstElementChild;
      const cardWidth = card ? card.offsetWidth : track.clientWidth;
      return window.innerWidth <= 640 ? cardWidth : (cardWidth * 2) + 16;
    };

    // Drag-to-scroll support (Mouse & Touch)
    let isDown = false;
    let startX = 0;
    let scrollLeftPos = 0;
    let hasDragged = false;

    const startDrag = (e) => {
      isDown = true;
      hasDragged = false;
      const pageX = e.touches ? e.touches[0].pageX : e.pageX;
      startX = pageX - track.offsetLeft;
      scrollLeftPos = track.scrollLeft;
      track.classList.add('is-dragging');
    };

    const stopDrag = () => {
      if (!isDown) return;
      isDown = false;
      track.classList.remove('is-dragging');
    };

    const doDrag = (e) => {
      if (!isDown) return;
      const pageX = e.touches ? e.touches[0].pageX : e.pageX;
      const x = pageX - track.offsetLeft;
      const walk = (x - startX) * 1.3;
      if (Math.abs(walk) > 6) {
        hasDragged = true;
        if (e.cancelable) e.preventDefault();
      }
      track.scrollLeft = scrollLeftPos - walk;
    };

    track.addEventListener('mousedown', startDrag);
    track.addEventListener('mouseleave', stopDrag);
    track.addEventListener('mouseup', stopDrag);
    track.addEventListener('mousemove', doDrag);

    // Prevent link redirection when user is dragging
    track.addEventListener('click', (e) => {
      if (hasDragged) {
        e.preventDefault();
        e.stopPropagation();
        hasDragged = false;
      }
    }, true);

    if (prevBtn) {
      prevBtn.addEventListener('click', (e) => {
        e.preventDefault();
        track.style.scrollBehavior = 'smooth';
        track.scrollBy({ left: -getScrollStep(), behavior: 'smooth' });
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', (e) => {
        e.preventDefault();
        track.style.scrollBehavior = 'smooth';
        track.scrollBy({ left: getScrollStep(), behavior: 'smooth' });
      });
    }
  });
}

/* Slot Characters Popup Modal with "JOIN NOW" CTA */
function initJoinNowPopupModal() {
  let modalOverlay = document.getElementById('join-now-modal');

  // Create modal dynamically if not already in DOM
  if (!modalOverlay) {
    modalOverlay = document.createElement('div');
    modalOverlay.id = 'join-now-modal';
    modalOverlay.className = 'modal-overlay';
    modalOverlay.innerHTML = `
      <div class="modal-content-card">
        <button class="modal-close-x" id="modal-close-trigger" aria-label="Close Popup">&times;</button>
        <div class="slot-popup-banner">
          <a href="https://gperya-apk.com/playnow" rel="${getPlaynowRel()}">
          <img src="/assets/images/promos/gperya join now.webp" alt="gperya join now" width="800" height="360" loading="eager">
          </a>
        </div>
        <div class="slot-popup-body">
          <span class="slot-popup-title">🎰 Exclusive Gperya VIP Slot Lobby</span>
          <p class="slot-popup-subtitle">
            Play legendary slots including Starlight Princess, Fa Chai Fortune, and Gates of Olympus with 100% Welcome Bonus!
          </p>
          <div style="display: flex; justify-content: center; gap: 12px; margin-top: 12px; flex-wrap: wrap;">
            <a href="https://gperya-apk.com/playnow" class="btn btn-gold btn-lg" style="font-size: 1.15rem; padding: 14px 32px;" rel="${getPlaynowRel()}">
              🔥 JOIN NOW & PLAY
            </a>
          </div>
          <p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 10px;">
            21+ Only • Fast GCash & Maya Cashouts • Official Verified Link
          </p>
        </div>
      </div>
    `;
    document.body.appendChild(modalOverlay);
  }

  const closeTrigger = modalOverlay.querySelector('#modal-close-trigger');

  function openPopup() {
    modalOverlay.classList.add('open');
  }

  function closePopup() {
    modalOverlay.classList.remove('open');
  }

  if (closeTrigger) {
    closeTrigger.addEventListener('click', closePopup);
  }

  modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) closePopup();
  });

  let popupTriggeredOnScroll = false;

  function checkScrollForPopup() {
    if (popupTriggeredOnScroll) return;

    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const windowHeight = window.innerHeight || document.documentElement.clientHeight;
    const totalScrollableHeight = document.documentElement.scrollHeight - windowHeight;

    if (totalScrollableHeight > 0) {
      const scrollPercent = (scrollTop / totalScrollableHeight) * 100;
      if (scrollPercent >= 58) { // Triggers around 60% scroll depth
        popupTriggeredOnScroll = true;
        openPopup();
        window.removeEventListener('scroll', checkScrollForPopup);
      }
    }
  }

  // Listen to window scroll event
  window.addEventListener('scroll', checkScrollForPopup, { passive: true });

  // Check immediately in case page is loaded already scrolled or short
  setTimeout(checkScrollForPopup, 300);

  // Trigger popup on any element with data-open-popup
  document.querySelectorAll('[data-open-popup]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openPopup();
    });
  });
}

/* Floating Bottom-Left CTA Widget with Moving Roulette Wheel & Play Now */
function initBottomLeftFloatingCTA() {
  let floatWidget = document.getElementById('floating-cta-widget');

  if (!floatWidget) {
    floatWidget = document.createElement('div');
    floatWidget.id = 'floating-cta-widget';
    floatWidget.className = 'floating-bottom-left-cta';
    floatWidget.innerHTML = `
      <a href="https://gperya-apk.com/playnow" style="display:flex; align-items:center; gap:10px; text-decoration:none;" rel="${getPlaynowRel()}" target="_blank">
        <div class="roulette-spin-container">
          <img src="/assets/images/roulette-wheel.svg" alt="Moving Casino Roulette Wheel" class="roulette-spin-img" width="54" height="54">
        </div>
        <div class="floating-cta-text">
          <span class="floating-cta-title">🎰 PLAY GPERYA</span>
          <span class="floating-cta-sub">Live Slots & Roulette</span>
        </div>
        <span class="btn btn-gold btn-sm" style="margin-left:4px; box-shadow:0 4px 10px rgba(255,199,0,0.4); font-weight:900;">PLAY NOW</span>
      </a>
      <button class="floating-cta-close" id="float-cta-close-btn" aria-label="Dismiss Floating CTA">&times;</button>
    `;
    document.body.appendChild(floatWidget);
  }

  const closeBtn = floatWidget.querySelector('#float-cta-close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      floatWidget.classList.add('hidden');
    });
  }
}

/* Interactive Lucky Spin Roulette Wheel */
function initSpinWheelWidget() {
  const spinBtn = document.getElementById('lucky-wheel-spin-btn');
  const wheelSvg = document.getElementById('lucky-wheel-svg');
  const spinTriggerBtn = document.getElementById('lucky-wheel-trigger-cta');

  if (!spinBtn || !wheelSvg) return;

  let isSpinning = false;
  let currentRotation = 0;

  const prizes = [
    '₱888 Free Bonus Cash',
    '100 Free Spins on Starlight Princess',
    '50% Deposit Match Bonus',
    '₱188 Instant Cash Gift',
    'VIP Lucky Draw Entry',
    '₱3,888 Mega Bonus Pack'
  ];

  // SVG segment centers, clockwise from the top-right ₱888 segment.
  const segmentCenterAngles = [300, 0, 60, 120, 180, 240];
  const pointerAngle = 270;

  function handleSpin() {
    if (isSpinning) return;
    isSpinning = true;

    const prizeIndex = Math.floor(Math.random() * prizes.length);
    const targetRotation = (pointerAngle - segmentCenterAngles[prizeIndex] + 360) % 360;
    const currentNormalizedRotation = ((currentRotation % 360) + 360) % 360;
    const rotationDelta = (targetRotation - currentNormalizedRotation + 360) % 360;
    const fullTurns = 5 + Math.floor(Math.random() * 3);
    currentRotation += (fullTurns * 360) + rotationDelta;

    wheelSvg.style.transform = `rotate(${currentRotation}deg)`;

    setTimeout(() => {
      isSpinning = false;
      const wonPrize = prizes[prizeIndex];

      // Trigger win modal / alert
      let winModal = document.getElementById('wheel-win-modal');
      if (!winModal) {
        winModal = document.createElement('div');
        winModal.id = 'wheel-win-modal';
        winModal.className = 'modal-overlay open';
        winModal.innerHTML = `
          <div class="modal-content-card" style="text-align:center; max-width:400px; padding:28px;">
            <button class="modal-close-x" onclick="document.getElementById('wheel-win-modal').classList.remove('open')">&times;</button>
            <div style="font-size:3rem; margin-bottom:8px;">🎁🎉</div>
            <h3 style="font-size:1.4rem; font-weight:900; color:#f3c64c; margin-bottom:6px;">CONGRATULATIONS!</h3>
            <p style="font-size:1.1rem; font-weight:700; color:#ffffff; margin-bottom:14px;">You Won: <span id="win-prize-name" style="color:#f3c64c;"></span></p>
            <p style="font-size:0.85rem; color:#8cb89f; margin-bottom:20px;">Claim your reward instantly on official Gperya portal!</p>
            <a href="https://gperya-apk.com/playnow" class="jackpot-btn-play" style="width:100%;" rel="${getPlaynowRel()}" target="_blank">🔥 CLAIM PRIZE NOW</a>
          </div>
        `;
        document.body.appendChild(winModal);
      }

      const prizeNameEl = document.getElementById('win-prize-name');
      if (prizeNameEl) prizeNameEl.textContent = wonPrize;
      winModal.classList.add('open');

    }, 4100);
  }

  spinBtn.addEventListener('click', handleSpin);
  if (spinTriggerBtn) {
    spinTriggerBtn.addEventListener('click', (e) => {
      e.preventDefault();
      handleSpin();
    });
  }
}

/* Dynamic Custom Blog Injector */
function initCustomBlogsInjector() {
  const blogGrids = document.querySelectorAll('.blog-grid');
  if (!blogGrids.length) return;

  const customBlogs = JSON.parse(localStorage.getItem('gperya_custom_blogs') || '[]');
  if (!customBlogs.length) return;

  blogGrids.forEach(grid => {
    customBlogs.forEach(blog => {
      const card = document.createElement('article');
      card.className = 'article-card custom-article-card';

      const thumbImg = blog.featuredImage || '/uploads/blogs/default-featured.svg';
      const blogUrl = `/blog/${encodeURIComponent(blog.slug || blog.id)}/`;

      card.innerHTML = `
        <div class="article-thumb">
          <a href="${blogUrl}"><img src="${thumbImg}" alt="${escapeHtml(blog.title)}" loading="lazy"></a>
        </div>
        <div class="article-body">
          <div class="article-meta">
            <span class="badge badge-yellow">${escapeHtml(blog.category)}</span>
            <time datetime="${blog.date}">${blog.date}</time>
          </div>
          <h3 class="article-title">
            <a href="${blogUrl}" style="color:inherit; text-decoration:none;">${escapeHtml(blog.title)}</a>
          </h3>
          <p class="article-excerpt">${escapeHtml(blog.excerpt)}</p>
          <div style="display: flex; justify-content: space-between; align-items: center; margin-top: auto;">
            <span style="font-size:0.75rem; color:var(--text-muted);">By ${escapeHtml(blog.author)}</span>
            <a href="${blogUrl}" style="color: var(--brand); font-weight: 700; font-size: 0.8rem; text-decoration: none;">Read Article &rarr;</a>
          </div>
        </div>
      `;

      grid.prepend(card);
    });
  });

  function escapeHtml(str) {
    return (str || '').replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
}

/* Secret Admin Keyboard Shortcut & Triple Click */
function initSecretAdminShortcut() {
  // Keyboard shortcut: Ctrl + Shift + A or Alt + Shift + A
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.altKey) && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
      e.preventDefault();
      window.location.href = '/admin/';
    }
  });

  // Triple-click brand logo shortcut
  const brandLogos = document.querySelectorAll('.brand-logo');
  brandLogos.forEach(logo => {
    let clickCount = 0;
    let clickTimer = null;
    logo.addEventListener('click', (e) => {
      clickCount++;
      if (clickCount === 3) {
        e.preventDefault();
        window.location.href = '/admin/';
      }
      clearTimeout(clickTimer);
      clickTimer = setTimeout(() => {
        clickCount = 0;
      }, 800);
    });
  });
}

/* Ensure affiliate links carry rel and target and redirect to target */
function enhanceAffiliateLinks() {
  const redirectTarget = (window.SITE_CONFIG && window.SITE_CONFIG.redirectTarget) ? window.SITE_CONFIG.redirectTarget : 'https://bybet.com/p/xjSD';

  // Global handler so clicking any gperya-apk.com/playnow link redirects to target
  document.addEventListener('click', (e) => {
    const link = e.target.closest('a');
    if (!link) return;
    const href = link.getAttribute('href') || '';
    if (href.includes('gperya-apk.com/playnow') || href === '/playnow' || href === '/playnow/' || href.includes('playnow')) {
      e.preventDefault();
      window.open(redirectTarget, link.target || '_blank');
    }
  });

  const links = document.querySelectorAll('a[href*="gperya-apk.com"], a[href*="playnow"]');
  links.forEach(link => {
    link.setAttribute('rel', getPlaynowRel());
    link.setAttribute('target', '_blank');
  });
}

/* Dynamic Random Winner Marquee Announcement */
function initDynamicWinnerMarquee() {
  const winnerElements = document.querySelectorAll('.winner-alert-msg');
  if (!winnerElements.length) return;

  const userPool = ['user_82', 'mar_91', 'joh_33', 'alb_88', 'chr_52', 'nik_14', 'ram_67', 'kat_09', 'dan_45', 'ste_23', 'ken_81', 'vic_19', 'pat_76', 'san_34', 'leo_92', 'ria_58', 'mya_07', 'rix_41', 'rey_28', 'jun_63', 'bjo_11', 'dax_99', 'sol_77', 'vince_04', 'mark_85'];
  const gamePool = ['Dragon Fortune Slot', 'Super Ace Slot', 'Fortune Gems 2', 'Money Coming Slot', 'Crazy 777', 'Color Game', 'Mega Fishing', 'Golden Empire', 'Tongits Go', 'Speed Baccarat', 'Boxing King', 'Roma X Slot', 'Ganesha Gold', 'Lucky Neko', 'Wild Bandito'];

  function generateWinnerMsg() {
    const user = userPool[Math.floor(Math.random() * userPool.length)];
    const game = gamePool[Math.floor(Math.random() * gamePool.length)];
    // Generate random prize between ₱15,000 and ₱385,000 in steps of 500
    const prizeNum = Math.floor(Math.random() * 740 + 30) * 500;
    const prize = '₱' + prizeNum.toLocaleString('en-US');

    return `📢 Big Winner Alert! Player [${user}**] won ${prize} on ${game}!`;
  }

  // Set initial random winner message immediately
  const initialMsg = generateWinnerMsg();
  winnerElements.forEach(el => {
    el.textContent = initialMsg;
  });

  // Rotate winner message every 6 seconds
  setInterval(() => {
    const newMsg = generateWinnerMsg();
    winnerElements.forEach(el => {
      el.textContent = newMsg;
    });
  }, 6000);
}

/* Pragmatic Play Slot Demo Official iFrame Player */
function initPragmaticDemoSection() {
  const sections = document.querySelectorAll('.pragmatic-demo-section');
  if (!sections.length) return;

  const demoData = {
    'gates-olympus': {
      title: 'Gates of Olympus 1000',
      rtp: '96.51% RTP • ⚡ High Volatility',
      iframeUrl: 'https://slotslaunch.com/iframe/16716?token=KljjshkJEwm9XlVUTiGCzsyYkQw4mG22pOKNzS3enaABIHoTdj'
    },
    'sweet-bonanza': {
      title: 'Sweet Bonanza 1000',
      rtp: '96.51% RTP • ⚡ High Volatility',
      iframeUrl: 'https://demogamesfree.dorwemqgtv.net/gs2c/openGame.do?gameSymbol=vs20fruitswx&lang=en&stylename=g128pr_bybet&treq=tqjYh2EFVNef8XnlFJJNokeu4vrptKrSjxPoEtMXi8rC3Dqx0uAoU5WGojKVpMbC&isGameUrlApiCalled=true&userId=demoPlayer'
    },
    'starlight-princess': {
      title: 'Starlight Princess 1000',
      rtp: '96.50% RTP • ⚡ High Volatility',
      iframeUrl: 'https://demogamesfree.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20starlight&websiteUrl=https%3A%2F%2Fwww.pragmaticplay.com&jurisdiction=99'
    },
    'sugar-rush': {
      title: 'Sugar Rush 1000',
      rtp: '96.53% RTP • ⚡ High Volatility',
      iframeUrl: 'https://demogamesfree.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20sugarrush&websiteUrl=https%3A%2F%2Fwww.pragmaticplay.com&jurisdiction=99'
    },
    'big-bass': {
      title: 'Big Bass Splash',
      rtp: '96.71% RTP • ⚡ High Volatility',
      iframeUrl: 'https://demogamesfree.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs10bbbonanza&websiteUrl=https%3A%2F%2Fwww.pragmaticplay.com&jurisdiction=99'
    },
    'wolf-gold': {
      title: 'Wolf Gold',
      rtp: '96.01% RTP • 🔥 Medium Volatility',
      iframeUrl: 'https://demogamesfree.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs25wolfgold&websiteUrl=https%3A%2F%2Fwww.pragmaticplay.com&jurisdiction=99'
    }
  };

  sections.forEach(section => {
    const tabs = section.querySelectorAll('.demo-game-tab');
    const nameEl = section.querySelector('.demo-game-name');
    const rtpEl = section.querySelector('.demo-rtp-badge');
    const iframeEl = section.querySelector('.demo-iframe-wrap');
    const loadDemoFrame = () => {
      if (!iframeEl || iframeEl.src || !iframeEl.dataset.src) return;
      iframeEl.src = iframeEl.dataset.src;
      iframeEl.classList.add('is-loaded');
    };

    if (iframeEl && iframeEl.dataset.src) {
      if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver(entries => {
          if (entries.some(entry => entry.isIntersecting)) {
            loadDemoFrame();
            observer.disconnect();
          }
        }, { rootMargin: '120px 0px' });
        observer.observe(iframeEl);
      } else {
        runWhenIdle(loadDemoFrame);
      }
    }

    tabs.forEach(tab => {
      tab.addEventListener('click', (e) => {
        e.preventDefault();
        const gameKey = tab.getAttribute('data-game');
        const data = demoData[gameKey];
        if (!data) return;

        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        if (nameEl) nameEl.textContent = data.title;
        if (rtpEl) rtpEl.textContent = data.rtp;
        if (iframeEl) {
          iframeEl.dataset.src = data.iframeUrl;
          iframeEl.src = data.iframeUrl;
          iframeEl.classList.add('is-loaded');
        }
      });
    });
  });
}
